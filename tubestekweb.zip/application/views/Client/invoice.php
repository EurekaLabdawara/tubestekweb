<body onload="print()">
<h2>Detail Tagihan</h2>
<h4>Pembayaran</h4>
<hr class="my-4">
<div class="row">
<div class="col">
<div class="float-right">
<p>Total Belanja</p>
<p class="">Rp. 50.000</p>
<p>Biaya Layanan</p>
<hr class="my-4">
<p class="">+ Rp122</p>
<p>Total Bayar</p>
<p class="text-muted">Transfer Manual</p>
<p class="">Rp. 50.122</p>
<p>Produk Yang Dibeli</p>
<p>Vitaa Shop</p>
<hr class="my-4">
<p>Case Bumper Iphone</p>
<p class="text-right text-muted">1 X Rp50.000</p>
<p class="">Rp50.000</p>
<p>Ongkos Kirim</p>
<p class="text-muted">Next Day (1 hari)</p>
<p class="text-muted">adhyaksa 3 no 3</p>
<p class="">Rp14.000</p>
</div>
</div>
</div>
</body>